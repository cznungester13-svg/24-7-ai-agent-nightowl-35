// Owns: lead data access — create, query.
const pool = require('./index');

async function createLead({ name, email, businessName, painPoint }) {
  const result = await pool.query(
    `INSERT INTO leads (name, email, business_name, pain_point)
     VALUES ($1, $2, $3, $4)
     RETURNING *`,
    [name, email.toLowerCase().trim(), businessName || null, painPoint || null]
  );
  return result.rows[0];
}

module.exports = { createLead };